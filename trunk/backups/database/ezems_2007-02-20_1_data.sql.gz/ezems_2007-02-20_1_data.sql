# Datenbackup: 20.02.2007 18:46 

# ----------------------------------------------------------
#
#
# data for table 'ezems_access'
#
INSERT INTO ezems_access VALUES ('1','0','0');
INSERT INTO ezems_access VALUES ('2','0','0');
INSERT INTO ezems_access VALUES ('3','0','0');
INSERT INTO ezems_access VALUES ('4','0','0');
INSERT INTO ezems_access VALUES ('5','0','0');
INSERT INTO ezems_access VALUES ('6','0','0');
INSERT INTO ezems_access VALUES ('7','0','0');
INSERT INTO ezems_access VALUES ('8','0','0');
INSERT INTO ezems_access VALUES ('9','0','0');
INSERT INTO ezems_access VALUES ('10','0','0');
INSERT INTO ezems_access VALUES ('11','0','0');
INSERT INTO ezems_access VALUES ('12','0','0');
INSERT INTO ezems_access VALUES ('13','0','0');
INSERT INTO ezems_access VALUES ('14','0','0');
INSERT INTO ezems_access VALUES ('15','0','0');
INSERT INTO ezems_access VALUES ('16','0','0');
INSERT INTO ezems_access VALUES ('17','0','0');
INSERT INTO ezems_access VALUES ('18','0','0');
INSERT INTO ezems_access VALUES ('19','0','0');
INSERT INTO ezems_access VALUES ('20','0','0');
INSERT INTO ezems_access VALUES ('21','0','0');
INSERT INTO ezems_access VALUES ('34','0','0');
INSERT INTO ezems_access VALUES ('35','0','0');
INSERT INTO ezems_access VALUES ('36','0','0');
INSERT INTO ezems_access VALUES ('37','0','0');
INSERT INTO ezems_access VALUES ('38','0','0');
INSERT INTO ezems_access VALUES ('39','0','0');
INSERT INTO ezems_access VALUES ('40','0','0');
INSERT INTO ezems_access VALUES ('41','0','0');
INSERT INTO ezems_access VALUES ('42','0','0');
INSERT INTO ezems_access VALUES ('43','0','0');
INSERT INTO ezems_access VALUES ('44','0','0');
INSERT INTO ezems_access VALUES ('45','0','0');
INSERT INTO ezems_access VALUES ('46','0','0');
INSERT INTO ezems_access VALUES ('47','0','0');
INSERT INTO ezems_access VALUES ('48','0','0');
INSERT INTO ezems_access VALUES ('49','0','0');
INSERT INTO ezems_access VALUES ('50','0','0');
INSERT INTO ezems_access VALUES ('51','0','0');
INSERT INTO ezems_access VALUES ('52','0','0');
INSERT INTO ezems_access VALUES ('53','0','0');
INSERT INTO ezems_access VALUES ('65','0','0');
INSERT INTO ezems_access VALUES ('66','0','0');
INSERT INTO ezems_access VALUES ('1','1','0');
INSERT INTO ezems_access VALUES ('3','1','0');
INSERT INTO ezems_access VALUES ('5','1','0');
INSERT INTO ezems_access VALUES ('6','1','0');
INSERT INTO ezems_access VALUES ('8','1','0');
INSERT INTO ezems_access VALUES ('9','1','0');
INSERT INTO ezems_access VALUES ('11','1','0');
INSERT INTO ezems_access VALUES ('12','1','0');
INSERT INTO ezems_access VALUES ('13','1','0');
INSERT INTO ezems_access VALUES ('14','1','0');
INSERT INTO ezems_access VALUES ('16','1','0');
INSERT INTO ezems_access VALUES ('17','1','0');
INSERT INTO ezems_access VALUES ('19','1','0');
INSERT INTO ezems_access VALUES ('20','1','0');
INSERT INTO ezems_access VALUES ('21','1','0');
INSERT INTO ezems_access VALUES ('34','1','0');
INSERT INTO ezems_access VALUES ('35','1','0');
INSERT INTO ezems_access VALUES ('36','1','0');
INSERT INTO ezems_access VALUES ('37','1','0');
INSERT INTO ezems_access VALUES ('38','1','0');
INSERT INTO ezems_access VALUES ('39','1','0');
INSERT INTO ezems_access VALUES ('40','1','0');
INSERT INTO ezems_access VALUES ('41','1','0');
INSERT INTO ezems_access VALUES ('42','1','0');
INSERT INTO ezems_access VALUES ('43','1','0');
INSERT INTO ezems_access VALUES ('44','1','0');
INSERT INTO ezems_access VALUES ('50','1','0');
INSERT INTO ezems_access VALUES ('51','1','0');
INSERT INTO ezems_access VALUES ('52','1','0');
INSERT INTO ezems_access VALUES ('53','1','0');
INSERT INTO ezems_access VALUES ('54','1','0');
INSERT INTO ezems_access VALUES ('65','1','0');
INSERT INTO ezems_access VALUES ('66','1','0');
INSERT INTO ezems_access VALUES ('2','1','1');
INSERT INTO ezems_access VALUES ('4','1','1');
INSERT INTO ezems_access VALUES ('7','1','1');
INSERT INTO ezems_access VALUES ('10','1','1');
INSERT INTO ezems_access VALUES ('15','1','1');
INSERT INTO ezems_access VALUES ('18','1','1');
INSERT INTO ezems_access VALUES ('45','1','1');
INSERT INTO ezems_access VALUES ('46','1','1');
INSERT INTO ezems_access VALUES ('47','1','1');
INSERT INTO ezems_access VALUES ('48','1','1');
INSERT INTO ezems_access VALUES ('49','1','1');
INSERT INTO ezems_access VALUES ('55','1','1');
INSERT INTO ezems_access VALUES ('56','1','1');
INSERT INTO ezems_access VALUES ('2','2','0');
INSERT INTO ezems_access VALUES ('1','2','1');
INSERT INTO ezems_access VALUES ('3','2','1');
INSERT INTO ezems_access VALUES ('4','2','1');
INSERT INTO ezems_access VALUES ('5','2','1');
INSERT INTO ezems_access VALUES ('6','2','1');
INSERT INTO ezems_access VALUES ('7','2','1');
INSERT INTO ezems_access VALUES ('8','2','1');
INSERT INTO ezems_access VALUES ('9','2','1');
INSERT INTO ezems_access VALUES ('10','2','1');
INSERT INTO ezems_access VALUES ('11','2','1');
INSERT INTO ezems_access VALUES ('12','2','1');
INSERT INTO ezems_access VALUES ('13','2','1');
INSERT INTO ezems_access VALUES ('14','2','1');
INSERT INTO ezems_access VALUES ('15','2','1');
INSERT INTO ezems_access VALUES ('16','2','1');
INSERT INTO ezems_access VALUES ('17','2','1');
INSERT INTO ezems_access VALUES ('18','2','1');
INSERT INTO ezems_access VALUES ('19','2','1');
INSERT INTO ezems_access VALUES ('20','2','1');
INSERT INTO ezems_access VALUES ('21','2','1');
INSERT INTO ezems_access VALUES ('34','2','1');
INSERT INTO ezems_access VALUES ('35','2','1');
INSERT INTO ezems_access VALUES ('36','2','1');
INSERT INTO ezems_access VALUES ('37','2','1');
INSERT INTO ezems_access VALUES ('38','2','1');
INSERT INTO ezems_access VALUES ('39','2','1');
INSERT INTO ezems_access VALUES ('40','2','1');
INSERT INTO ezems_access VALUES ('41','2','1');
INSERT INTO ezems_access VALUES ('42','2','1');
INSERT INTO ezems_access VALUES ('43','2','1');
INSERT INTO ezems_access VALUES ('44','2','1');
INSERT INTO ezems_access VALUES ('45','2','1');
INSERT INTO ezems_access VALUES ('46','2','1');
INSERT INTO ezems_access VALUES ('47','2','1');
INSERT INTO ezems_access VALUES ('48','2','1');
INSERT INTO ezems_access VALUES ('49','2','1');
INSERT INTO ezems_access VALUES ('50','2','1');
INSERT INTO ezems_access VALUES ('51','2','1');
INSERT INTO ezems_access VALUES ('52','2','1');
INSERT INTO ezems_access VALUES ('53','2','1');
INSERT INTO ezems_access VALUES ('54','2','1');
INSERT INTO ezems_access VALUES ('55','2','1');
INSERT INTO ezems_access VALUES ('56','2','1');
INSERT INTO ezems_access VALUES ('62','2','1');
INSERT INTO ezems_access VALUES ('63','2','1');
INSERT INTO ezems_access VALUES ('65','2','1');
INSERT INTO ezems_access VALUES ('66','2','1');
INSERT INTO ezems_access VALUES ('67','2','1');
INSERT INTO ezems_access VALUES ('68','2','1');
INSERT INTO ezems_access VALUES ('69','2','1');
INSERT INTO ezems_access VALUES ('70','2','1');
INSERT INTO ezems_access VALUES ('71','2','1');
INSERT INTO ezems_access VALUES ('72','2','1');
INSERT INTO ezems_access VALUES ('73','2','1');
INSERT INTO ezems_access VALUES ('74','2','1');
INSERT INTO ezems_access VALUES ('75','2','1');
INSERT INTO ezems_access VALUES ('1','4','0');
INSERT INTO ezems_access VALUES ('2','4','0');
INSERT INTO ezems_access VALUES ('3','4','0');
INSERT INTO ezems_access VALUES ('4','4','0');
INSERT INTO ezems_access VALUES ('5','4','0');
INSERT INTO ezems_access VALUES ('6','4','0');
INSERT INTO ezems_access VALUES ('7','4','0');
INSERT INTO ezems_access VALUES ('8','4','0');
INSERT INTO ezems_access VALUES ('9','4','0');
INSERT INTO ezems_access VALUES ('10','4','0');
INSERT INTO ezems_access VALUES ('11','4','0');
INSERT INTO ezems_access VALUES ('12','4','0');
INSERT INTO ezems_access VALUES ('13','4','0');
INSERT INTO ezems_access VALUES ('14','4','0');
INSERT INTO ezems_access VALUES ('15','4','0');
INSERT INTO ezems_access VALUES ('16','4','0');
INSERT INTO ezems_access VALUES ('17','4','0');
INSERT INTO ezems_access VALUES ('18','4','0');
INSERT INTO ezems_access VALUES ('19','4','0');
INSERT INTO ezems_access VALUES ('20','4','0');
INSERT INTO ezems_access VALUES ('21','4','0');
INSERT INTO ezems_access VALUES ('34','4','0');
INSERT INTO ezems_access VALUES ('35','4','0');
INSERT INTO ezems_access VALUES ('36','4','0');
INSERT INTO ezems_access VALUES ('37','4','0');
INSERT INTO ezems_access VALUES ('38','4','0');
INSERT INTO ezems_access VALUES ('39','4','0');
INSERT INTO ezems_access VALUES ('40','4','0');
INSERT INTO ezems_access VALUES ('41','4','0');
INSERT INTO ezems_access VALUES ('42','4','0');



# ----------------------------------------------------------
#
#
# data for table 'ezems_bbcode'
#



# ----------------------------------------------------------
#
#
# data for table 'ezems_captcha'
#
INSERT INTO ezems_captcha VALUES ('1','Keckse');



# ----------------------------------------------------------
#
#
# data for table 'ezems_clandb'
#
INSERT INTO ezems_clandb VALUES ('1','test','','','','','');



# ----------------------------------------------------------
#
#
# data for table 'ezems_clanwars'
#
INSERT INTO ezems_clanwars VALUES ('1','1','0','1','1','|�|1','test|�|','915149400','1:',':1:1:1:1','');



# ----------------------------------------------------------
#
#
# data for table 'ezems_errors'
#



# ----------------------------------------------------------
#
#
# data for table 'ezems_games'
#
INSERT INTO ezems_games VALUES ('1','CounterStrike','2.0','Valve','www.steampowered.com','');
INSERT INTO ezems_games VALUES ('2','Enemy Territory','2.6b','Splash Damage','http://www.splashdamage.com/','');



# ----------------------------------------------------------
#
#
# data for table 'ezems_groups'
#
INSERT INTO ezems_groups VALUES ('1','Unregistred','http://www.ec-cp.net','Unregistrierte User','1148221618');
INSERT INTO ezems_groups VALUES ('2','Administratoren','http://www.ec-cp.net','Administratoren','1148221618');



# ----------------------------------------------------------
#
#
# data for table 'ezems_icons'
#
INSERT INTO ezems_icons VALUES ('1','default','Default Symbols','Phoenix','http://www.ec-cp.net','Standart Symbole','1148221618');



# ----------------------------------------------------------
#
#
# data for table 'ezems_languages'
#
INSERT INTO ezems_languages VALUES ('1','german_ch','Deutsch - Schweiz','Phoenix','http://www.ec-cp.net','','1148221618');
INSERT INTO ezems_languages VALUES ('2','english_uk','English - UK','Phoenix','http://www.ec-cp.net',' ','1148221618');
INSERT INTO ezems_languages VALUES ('3','german_de','Deutsch - Deutschland','Phoenix','http://www.ec-cp.net',' ','1148221618');



# ----------------------------------------------------------
#
#
# data for table 'ezems_maps'
#
INSERT INTO ezems_maps VALUES ('1','dust','','1');



# ----------------------------------------------------------
#
#
# data for table 'ezems_player'
#
INSERT INTO ezems_player VALUES ('1','1','1','1');
INSERT INTO ezems_player VALUES ('2','2','2','1');



# ----------------------------------------------------------
#
#
# data for table 'ezems_plugins'
#
INSERT INTO ezems_plugins VALUES ('1','system','Systemapplikation','Phoenix','http://www.ec-cp.net','Der Systemkern','1148219565','','','settings,plugins');
INSERT INTO ezems_plugins VALUES ('2','users','Usersverwaltung','Phoenix','http://www.ec-cp.net','Benutzerverwaltung & Loginsystem','0','','system','users');
INSERT INTO ezems_plugins VALUES ('3','errors','Fehlermeldungen','Phoenix','http://www.ec-cp.net','Systemfehlermeldungen wie 403, 404 u.s.w.','0',' ','system,users,errors','');
INSERT INTO ezems_plugins VALUES ('4','groups','Access Gruppenverwaltung','Phoenix','http://www.ec-cp.net','Accessgruppen','0',' ','system,users','groups,access');
INSERT INTO ezems_plugins VALUES ('6','captcha','Captcha','Phoenix','http://www.ec-cp.net','Captchafunktion','1157739371','','system','captcha');
INSERT INTO ezems_plugins VALUES ('7','bbcode','BBCode','Phoenix','http://www.ezems.net','BBCodes, Smileys etc.','1169226563','','','bbcode');
INSERT INTO ezems_plugins VALUES ('8','stats','Statistiken','Phoenix','http://www.ezems.net','Besucherstatistiken, Sidecounter','1169227145','','','stats');
INSERT INTO ezems_plugins VALUES ('9','clanwars','Clanwar','Master','http://www.ezems.net','Mit diesem Modul kannst du deine gesammten Clanwars verwalten','1169387632','','clanwars','clanwars');
INSERT INTO ezems_plugins VALUES ('10','games','Games','Master','http://www.ezems.net','Mit diesem Modul verwaltest du alle Spiele','1171522189','','-','games');



# ----------------------------------------------------------
#
#
# data for table 'ezems_settings'
#
INSERT INTO ezems_settings VALUES ('1','system','defaultPlugin','system');
INSERT INTO ezems_settings VALUES ('2','system','defaultSite','admin');
INSERT INTO ezems_settings VALUES ('4','system','contentWidth','');
INSERT INTO ezems_settings VALUES ('5','system','contentTyp','');
INSERT INTO ezems_settings VALUES ('6','system','defaultThemeId','1');
INSERT INTO ezems_settings VALUES ('7','system','title','Ezems - Web CMS');
INSERT INTO ezems_settings VALUES ('8','system','defaultTemplateId','1');
INSERT INTO ezems_settings VALUES ('9','system','defaultIconId','1');
INSERT INTO ezems_settings VALUES ('10','system','defaultLanguageId','3');
INSERT INTO ezems_settings VALUES ('11','system','defaultGroupId','1');
INSERT INTO ezems_settings VALUES ('12','system','usualRefererTime','1');
INSERT INTO ezems_settings VALUES ('13','system','version','0.5.0.3-beta-1');
INSERT INTO ezems_settings VALUES ('14','system','dataPerPage','20');
INSERT INTO ezems_settings VALUES ('3','system','siteOnline','1');
INSERT INTO ezems_settings VALUES ('15','system','mailDefaultAdress','auto@email.com');
INSERT INTO ezems_settings VALUES ('16','system','mailSubjectPrefix','[eZems.net]');
INSERT INTO ezems_settings VALUES ('18','stats','online','1');
INSERT INTO ezems_settings VALUES ('19','stats','today','1');
INSERT INTO ezems_settings VALUES ('20','stats','yesterday','1');
INSERT INTO ezems_settings VALUES ('21','stats','month','1');
INSERT INTO ezems_settings VALUES ('22','stats','all','1');
INSERT INTO ezems_settings VALUES ('23','stats','hits','1');
INSERT INTO ezems_settings VALUES ('24','captcha','font','RAVIE');
INSERT INTO ezems_settings VALUES ('25','clanwars','commentPersmission','1');
INSERT INTO ezems_settings VALUES ('26','clanwars','pics','1');
INSERT INTO ezems_settings VALUES ('27','clanwars','archiver','1');



# ----------------------------------------------------------
#
#
# data for table 'ezems_sites'
#
INSERT INTO ezems_sites VALUES ('1','1','admin','1');
INSERT INTO ezems_sites VALUES ('2','2','navlogin','1');
INSERT INTO ezems_sites VALUES ('3','2','navmenu','1');
INSERT INTO ezems_sites VALUES ('4','2','login','1');
INSERT INTO ezems_sites VALUES ('5','2','logout','1');
INSERT INTO ezems_sites VALUES ('6','2','home','1');
INSERT INTO ezems_sites VALUES ('7','3','404','1');
INSERT INTO ezems_sites VALUES ('8','2','manage','1');
INSERT INTO ezems_sites VALUES ('9','4','manage','1');
INSERT INTO ezems_sites VALUES ('10','1','rsslink','1');
INSERT INTO ezems_sites VALUES ('11','2','rss','4');
INSERT INTO ezems_sites VALUES ('12','1','settings','2');
INSERT INTO ezems_sites VALUES ('13','1','server','2');
INSERT INTO ezems_sites VALUES ('14','1','packages','2');
INSERT INTO ezems_sites VALUES ('15','2','navonline','1');
INSERT INTO ezems_sites VALUES ('16','1','database','2');
INSERT INTO ezems_sites VALUES ('17','1','development','2');
INSERT INTO ezems_sites VALUES ('18','1','about','1');
INSERT INTO ezems_sites VALUES ('19','6','system','3');
INSERT INTO ezems_sites VALUES ('20','6','manage','1');
INSERT INTO ezems_sites VALUES ('21','4','access','1');
INSERT INTO ezems_sites VALUES ('34','2','add','1');
INSERT INTO ezems_sites VALUES ('35','2','edit','1');
INSERT INTO ezems_sites VALUES ('36','2','remove','1');
INSERT INTO ezems_sites VALUES ('37','4','add','1');
INSERT INTO ezems_sites VALUES ('38','4','edit','1');
INSERT INTO ezems_sites VALUES ('39','4','remove','1');
INSERT INTO ezems_sites VALUES ('40','2','usercenter','1');
INSERT INTO ezems_sites VALUES ('41','2','changepassword','7');
INSERT INTO ezems_sites VALUES ('42','2','changetheme','7');
INSERT INTO ezems_sites VALUES ('43','2','changetemplate','7');
INSERT INTO ezems_sites VALUES ('44','2','changelanguage','7');
INSERT INTO ezems_sites VALUES ('53','7','delete','1');
INSERT INTO ezems_sites VALUES ('52','7','manage','1');
INSERT INTO ezems_sites VALUES ('51','7','edit','1');
INSERT INTO ezems_sites VALUES ('50','7','add','1');
INSERT INTO ezems_sites VALUES ('49','7','system','3');
INSERT INTO ezems_sites VALUES ('65','8','manage','1');
INSERT INTO ezems_sites VALUES ('45','8','system','3');
INSERT INTO ezems_sites VALUES ('46','8','online','1');
INSERT INTO ezems_sites VALUES ('47','8','list','1');
INSERT INTO ezems_sites VALUES ('48','8','navi','1');
INSERT INTO ezems_sites VALUES ('66','9','add','1');
INSERT INTO ezems_sites VALUES ('67','9','details','1');
INSERT INTO ezems_sites VALUES ('68','9','edit','1');
INSERT INTO ezems_sites VALUES ('69','9','list','1');
INSERT INTO ezems_sites VALUES ('70','9','manage','1');
INSERT INTO ezems_sites VALUES ('71','9','upload','1');
INSERT INTO ezems_sites VALUES ('72','10','manager','1');
INSERT INTO ezems_sites VALUES ('73','10','add','1');
INSERT INTO ezems_sites VALUES ('74','10','edit','1');
INSERT INTO ezems_sites VALUES ('75','10','delete','1');



# ----------------------------------------------------------
#
#
# data for table 'ezems_squads'
#
INSERT INTO ezems_squads VALUES ('1','1','1','1','');
INSERT INTO ezems_squads VALUES ('2','2','2','2','');



# ----------------------------------------------------------
#
#
# data for table 'ezems_stats'
#
INSERT INTO ezems_stats VALUES ('1','127.0.0.1','0','0','1171635542','users','home');
INSERT INTO ezems_stats VALUES ('2','127.0.0.1','0','0','1171635558','system','database');
INSERT INTO ezems_stats VALUES ('3','127.0.0.1','0','0','1171635571','system','database');
INSERT INTO ezems_stats VALUES ('4','127.0.0.1','0','0','1171635574','system','database');
INSERT INTO ezems_stats VALUES ('5','127.0.0.1','0','0','1171635577','system','database');
INSERT INTO ezems_stats VALUES ('6','127.0.0.1','0','0','1171635579','system','database');
INSERT INTO ezems_stats VALUES ('7','127.0.0.1','0','0','1171635583','system','database');
INSERT INTO ezems_stats VALUES ('8','127.0.0.1','0','0','1171635586','system','database');
INSERT INTO ezems_stats VALUES ('9','127.0.0.1','0','0','1171635613','system','database');
INSERT INTO ezems_stats VALUES ('10','127.0.0.1','0','0','1171635624','system','database');
INSERT INTO ezems_stats VALUES ('11','127.0.0.1','0','0','1171635652','system','development');
INSERT INTO ezems_stats VALUES ('12','127.0.0.1','0','0','1171635727','system','development');
INSERT INTO ezems_stats VALUES ('13','127.0.0.1','0','0','1171635796','system','development');
INSERT INTO ezems_stats VALUES ('14','127.0.0.1','0','0','1171635837','system','development');
INSERT INTO ezems_stats VALUES ('15','127.0.0.1','0','0','1171635849','system','development');
INSERT INTO ezems_stats VALUES ('16','127.0.0.1','0','0','1171635924','system','development');
INSERT INTO ezems_stats VALUES ('17','127.0.0.1','0','0','1171635934','system','development');
INSERT INTO ezems_stats VALUES ('18','127.0.0.1','0','0','1171635937','system','development');
INSERT INTO ezems_stats VALUES ('19','127.0.0.1','0','0','1171635941','system','development');
INSERT INTO ezems_stats VALUES ('20','127.0.0.1','0','0','1171635942','system','development');
INSERT INTO ezems_stats VALUES ('21','127.0.0.1','0','0','1171636018','system','development');
INSERT INTO ezems_stats VALUES ('22','127.0.0.1','0','0','1171636029','system','development');
INSERT INTO ezems_stats VALUES ('23','127.0.0.1','0','0','1171636083','system','development');
INSERT INTO ezems_stats VALUES ('24','127.0.0.1','0','0','1171636108','errors','404');
INSERT INTO ezems_stats VALUES ('25','127.0.0.1','0','0','1171636122','system','packages');
INSERT INTO ezems_stats VALUES ('26','127.0.0.1','0','0','1171636142','system','rsslink');
INSERT INTO ezems_stats VALUES ('27','127.0.0.1','0','0','1171636166','system','server');
INSERT INTO ezems_stats VALUES ('28','127.0.0.1','0','0','1171636241','system','server');
INSERT INTO ezems_stats VALUES ('29','127.0.0.1','0','0','1171636328','system','server');
INSERT INTO ezems_stats VALUES ('30','127.0.0.1','0','0','1171636365','system','settings');
INSERT INTO ezems_stats VALUES ('31','127.0.0.1','0','0','1171636396','system','settings');
INSERT INTO ezems_stats VALUES ('32','127.0.0.1','0','0','1171636473','system','settings');
INSERT INTO ezems_stats VALUES ('33','127.0.0.1','0','0','1171636480','system','settings');
INSERT INTO ezems_stats VALUES ('34','127.0.0.1','0','0','1171636509','system','settings');
INSERT INTO ezems_stats VALUES ('35','127.0.0.1','0','0','1171636545','system','settings');
INSERT INTO ezems_stats VALUES ('36','127.0.0.1','0','0','1171636548','system','admin');
INSERT INTO ezems_stats VALUES ('37','127.0.0.1','0','0','1171636554','system','settings');
INSERT INTO ezems_stats VALUES ('38','127.0.0.1','0','0','1171636557','system','settings');
INSERT INTO ezems_stats VALUES ('39','127.0.0.1','0','0','1171636560','system','settings');
INSERT INTO ezems_stats VALUES ('40','127.0.0.1','0','0','1171636583','system','settings');
INSERT INTO ezems_stats VALUES ('41','127.0.0.1','0','0','1171636596','system','admin');
INSERT INTO ezems_stats VALUES ('42','127.0.0.1','0','0','1171636597','system','settings');
INSERT INTO ezems_stats VALUES ('43','127.0.0.1','0','0','1171636675','system','settings');
INSERT INTO ezems_stats VALUES ('44','127.0.0.1','0','0','1171636700','system','settings');
INSERT INTO ezems_stats VALUES ('45','127.0.0.1','0','0','1171636704','system','admin');
INSERT INTO ezems_stats VALUES ('46','127.0.0.1','0','0','1171636707','system','server');
INSERT INTO ezems_stats VALUES ('47','127.0.0.1','0','0','1171636710','system','settings');
INSERT INTO ezems_stats VALUES ('48','127.0.0.1','0','0','1171636712','system','settings');
INSERT INTO ezems_stats VALUES ('49','127.0.0.1','0','0','1171636717','system','settings');
INSERT INTO ezems_stats VALUES ('50','127.0.0.1','0','0','1171636719','system','admin');
INSERT INTO ezems_stats VALUES ('51','127.0.0.1','0','0','1171636757','captcha','manage');
INSERT INTO ezems_stats VALUES ('52','127.0.0.1','0','0','1171636760','captcha','manage');
INSERT INTO ezems_stats VALUES ('53','127.0.0.1','0','0','1171636779','captcha','manage');
INSERT INTO ezems_stats VALUES ('54','127.0.0.1','0','0','1171636781','captcha','manage');
INSERT INTO ezems_stats VALUES ('55','127.0.0.1','0','0','1171636782','captcha','manage');
INSERT INTO ezems_stats VALUES ('56','127.0.0.1','0','0','1171636783','captcha','manage');
INSERT INTO ezems_stats VALUES ('57','127.0.0.1','0','0','1171636784','captcha','manage');
INSERT INTO ezems_stats VALUES ('58','127.0.0.1','0','0','1171636785','captcha','manage');
INSERT INTO ezems_stats VALUES ('59','127.0.0.1','0','0','1171636786','captcha','manage');
INSERT INTO ezems_stats VALUES ('60','127.0.0.1','0','0','1171636787','captcha','manage');
INSERT INTO ezems_stats VALUES ('61','127.0.0.1','0','0','1171636883','captcha','manage');
INSERT INTO ezems_stats VALUES ('62','127.0.0.1','0','0','1171636885','captcha','manage');
INSERT INTO ezems_stats VALUES ('63','127.0.0.1','0','0','1171636886','captcha','manage');
INSERT INTO ezems_stats VALUES ('64','127.0.0.1','0','0','1171636928','captcha','manage');
INSERT INTO ezems_stats VALUES ('65','127.0.0.1','0','0','1171636949','captcha','manage');
INSERT INTO ezems_stats VALUES ('66','127.0.0.1','0','0','1171636988','captcha','manage');
INSERT INTO ezems_stats VALUES ('67','127.0.0.1','0','0','1171637000','captcha','manage');
INSERT INTO ezems_stats VALUES ('68','127.0.0.1','0','0','1171637004','captcha','manage');
INSERT INTO ezems_stats VALUES ('69','127.0.0.1','0','0','1171637008','captcha','manage');
INSERT INTO ezems_stats VALUES ('70','127.0.0.1','0','0','1171637010','captcha','manage');
INSERT INTO ezems_stats VALUES ('71','127.0.0.1','0','0','1171637011','captcha','manage');
INSERT INTO ezems_stats VALUES ('72','127.0.0.1','0','0','1171637012','captcha','manage');
INSERT INTO ezems_stats VALUES ('73','127.0.0.1','0','0','1171637015','captcha','manage');
INSERT INTO ezems_stats VALUES ('74','127.0.0.1','0','0','1171637017','captcha','manage');
INSERT INTO ezems_stats VALUES ('75','127.0.0.1','0','0','1171637021','captcha','manage');
INSERT INTO ezems_stats VALUES ('76','127.0.0.1','0','0','1171637022','captcha','manage');
INSERT INTO ezems_stats VALUES ('77','127.0.0.1','0','0','1171637024','captcha','manage');
INSERT INTO ezems_stats VALUES ('78','127.0.0.1','0','0','1171637028','captcha','manage');
INSERT INTO ezems_stats VALUES ('79','127.0.0.1','0','0','1171637030','captcha','manage');
INSERT INTO ezems_stats VALUES ('80','127.0.0.1','0','0','1171637032','captcha','manage');
INSERT INTO ezems_stats VALUES ('81','127.0.0.1','0','0','1171637037','captcha','manage');
INSERT INTO ezems_stats VALUES ('82','127.0.0.1','0','0','1171637039','captcha','manage');
INSERT INTO ezems_stats VALUES ('83','127.0.0.1','0','0','1171637041','captcha','manage');
INSERT INTO ezems_stats VALUES ('84','127.0.0.1','0','0','1171637043','captcha','manage');
INSERT INTO ezems_stats VALUES ('85','127.0.0.1','0','0','1171637045','captcha','manage');
INSERT INTO ezems_stats VALUES ('86','127.0.0.1','0','0','1171637047','captcha','manage');
INSERT INTO ezems_stats VALUES ('87','127.0.0.1','0','0','1171637048','captcha','manage');
INSERT INTO ezems_stats VALUES ('88','127.0.0.1','0','0','1171637050','captcha','manage');
INSERT INTO ezems_stats VALUES ('89','127.0.0.1','0','0','1171637055','captcha','manage');
INSERT INTO ezems_stats VALUES ('90','127.0.0.1','0','0','1171637073','captcha','manage');
INSERT INTO ezems_stats VALUES ('91','127.0.0.1','0','0','1171637074','captcha','manage');
INSERT INTO ezems_stats VALUES ('92','127.0.0.1','0','0','1171637076','captcha','manage');
INSERT INTO ezems_stats VALUES ('93','127.0.0.1','0','0','1171637077','captcha','manage');
INSERT INTO ezems_stats VALUES ('94','127.0.0.1','0','0','1171637099','errors','403');
INSERT INTO ezems_stats VALUES ('95','127.0.0.1','0','0','1171637158','errors','403');
INSERT INTO ezems_stats VALUES ('96','127.0.0.1','0','0','1171637169','errors','403');
INSERT INTO ezems_stats VALUES ('97','127.0.0.1','0','0','1171637169','errors','403');
INSERT INTO ezems_stats VALUES ('98','127.0.0.1','0','0','1171637180','errors','404');
INSERT INTO ezems_stats VALUES ('99','127.0.0.1','0','0','1171637192','errors','404');
INSERT INTO ezems_stats VALUES ('100','127.0.0.1','0','0','1171637204','errors','404');
INSERT INTO ezems_stats VALUES ('101','127.0.0.1','0','0','1171637205','errors','404');
INSERT INTO ezems_stats VALUES ('102','127.0.0.1','0','0','1171637209','errors','403');
INSERT INTO ezems_stats VALUES ('103','127.0.0.1','0','0','1171637236','groups','access');
INSERT INTO ezems_stats VALUES ('104','127.0.0.1','0','0','1171637265','system','admin');
INSERT INTO ezems_stats VALUES ('105','127.0.0.1','0','0','1171637267','users','manage');
INSERT INTO ezems_stats VALUES ('106','127.0.0.1','0','0','1171637268','system','admin');
INSERT INTO ezems_stats VALUES ('107','127.0.0.1','0','0','1171637269','groups','manage');
INSERT INTO ezems_stats VALUES ('108','127.0.0.1','0','0','1171637274','system','admin');
INSERT INTO ezems_stats VALUES ('109','127.0.0.1','0','0','1171637278','users','manage');
INSERT INTO ezems_stats VALUES ('110','127.0.0.1','0','0','1171637279','users','edit');
INSERT INTO ezems_stats VALUES ('111','127.0.0.1','0','0','1171637291','users','manage');
INSERT INTO ezems_stats VALUES ('112','127.0.0.1','0','0','1171637292','system','admin');
INSERT INTO ezems_stats VALUES ('113','127.0.0.1','0','0','1171637295','groups','manage');
INSERT INTO ezems_stats VALUES ('114','127.0.0.1','0','0','1171637304','groups','access');
INSERT INTO ezems_stats VALUES ('115','127.0.0.1','0','0','1171637371','groups','access');
INSERT INTO ezems_stats VALUES ('116','127.0.0.1','0','0','1171637393','groups','access');
INSERT INTO ezems_stats VALUES ('117','127.0.0.1','0','0','1171637447','groups','access');
INSERT INTO ezems_stats VALUES ('118','127.0.0.1','0','0','1171637461','groups','access');
INSERT INTO ezems_stats VALUES ('119','127.0.0.1','0','0','1171637510','groups','access');
INSERT INTO ezems_stats VALUES ('120','127.0.0.1','0','0','1171637528','groups','access');
INSERT INTO ezems_stats VALUES ('121','127.0.0.1','0','0','1171637545','groups','access');
INSERT INTO ezems_stats VALUES ('122','127.0.0.1','0','0','1171637551','groups','access');
INSERT INTO ezems_stats VALUES ('123','127.0.0.1','0','0','1171637583','groups','access');
INSERT INTO ezems_stats VALUES ('124','127.0.0.1','0','0','1171637614','groups','access');
INSERT INTO ezems_stats VALUES ('125','127.0.0.1','0','0','1171637622','groups','access');
INSERT INTO ezems_stats VALUES ('126','127.0.0.1','0','0','1171637642','groups','access');
INSERT INTO ezems_stats VALUES ('127','127.0.0.1','0','0','1171637655','groups','access');
INSERT INTO ezems_stats VALUES ('128','127.0.0.1','0','0','1171637670','groups','access');
INSERT INTO ezems_stats VALUES ('129','127.0.0.1','0','0','1171637697','groups','access');
INSERT INTO ezems_stats VALUES ('130','127.0.0.1','0','0','1171637780','groups','access');
INSERT INTO ezems_stats VALUES ('131','127.0.0.1','0','0','1171637787','groups','access');
INSERT INTO ezems_stats VALUES ('132','127.0.0.1','0','0','1171637883','groups','access');
INSERT INTO ezems_stats VALUES ('133','127.0.0.1','0','0','1171637965','groups','access');
INSERT INTO ezems_stats VALUES ('134','127.0.0.1','0','0','1171637989','groups','access');
INSERT INTO ezems_stats VALUES ('135','127.0.0.1','0','0','1171638034','groups','access');
INSERT INTO ezems_stats VALUES ('136','127.0.0.1','0','0','1171638041','groups','access');
INSERT INTO ezems_stats VALUES ('137','127.0.0.1','0','0','1171638153','errors','404');
INSERT INTO ezems_stats VALUES ('138','127.0.0.1','0','0','1171638154','groups','access');
INSERT INTO ezems_stats VALUES ('139','127.0.0.1','0','0','1171638175','errors','404');
INSERT INTO ezems_stats VALUES ('140','127.0.0.1','0','0','1171638178','groups','access');
INSERT INTO ezems_stats VALUES ('141','127.0.0.1','0','0','1171638189','groups','access');
INSERT INTO ezems_stats VALUES ('142','127.0.0.1','0','0','1171638199','groups','access');
INSERT INTO ezems_stats VALUES ('143','127.0.0.1','0','0','1171638213','groups','access');
INSERT INTO ezems_stats VALUES ('144','127.0.0.1','0','0','1171638231','groups','access');
INSERT INTO ezems_stats VALUES ('145','127.0.0.1','0','0','1171638266','groups','access');
INSERT INTO ezems_stats VALUES ('146','127.0.0.1','0','0','1171638273','groups','access');
INSERT INTO ezems_stats VALUES ('147','127.0.0.1','0','0','1171638281','groups','access');
INSERT INTO ezems_stats VALUES ('148','127.0.0.1','0','0','1171638333','groups','access');
INSERT INTO ezems_stats VALUES ('149','127.0.0.1','0','0','1171638364','groups','access');
INSERT INTO ezems_stats VALUES ('150','127.0.0.1','0','0','1171638374','groups','access');
INSERT INTO ezems_stats VALUES ('151','127.0.0.1','0','0','1171638391','groups','access');
INSERT INTO ezems_stats VALUES ('152','127.0.0.1','0','0','1171638398','groups','access');
INSERT INTO ezems_stats VALUES ('153','127.0.0.1','0','0','1171638410','groups','access');
INSERT INTO ezems_stats VALUES ('154','127.0.0.1','0','0','1171638464','groups','access');
INSERT INTO ezems_stats VALUES ('155','127.0.0.1','0','0','1171638501','groups','access');
INSERT INTO ezems_stats VALUES ('156','127.0.0.1','0','0','1171638514','groups','access');
INSERT INTO ezems_stats VALUES ('157','127.0.0.1','0','0','1171638542','groups','access');
INSERT INTO ezems_stats VALUES ('158','127.0.0.1','0','0','1171638641','groups','access');
INSERT INTO ezems_stats VALUES ('159','127.0.0.1','0','0','1171638646','groups','access');
INSERT INTO ezems_stats VALUES ('160','127.0.0.1','0','0','1171638649','groups','access');
INSERT INTO ezems_stats VALUES ('161','127.0.0.1','0','0','1171638652','groups','access');
INSERT INTO ezems_stats VALUES ('162','127.0.0.1','0','0','1171638655','groups','access');
INSERT INTO ezems_stats VALUES ('163','127.0.0.1','0','0','1171638663','groups','access');
INSERT INTO ezems_stats VALUES ('164','127.0.0.1','0','0','1171638678','groups','access');
INSERT INTO ezems_stats VALUES ('165','127.0.0.1','0','0','1171638844','groups','add');
INSERT INTO ezems_stats VALUES ('166','127.0.0.1','0','0','1171638883','groups','add');
INSERT INTO ezems_stats VALUES ('167','127.0.0.1','0','0','1171638925','groups','add');
INSERT INTO ezems_stats VALUES ('168','127.0.0.1','0','0','1171638932','groups','add');
INSERT INTO ezems_stats VALUES ('169','127.0.0.1','0','0','1171638981','groups','add');
INSERT INTO ezems_stats VALUES ('170','127.0.0.1','0','0','1171638996','groups','add');
INSERT INTO ezems_stats VALUES ('171','127.0.0.1','0','0','1171638998','groups','add');
INSERT INTO ezems_stats VALUES ('172','127.0.0.1','0','0','1171639020','groups','add');
INSERT INTO ezems_stats VALUES ('173','127.0.0.1','0','0','1171639054','groups','add');
INSERT INTO ezems_stats VALUES ('174','127.0.0.1','0','0','1171639070','groups','add');
INSERT INTO ezems_stats VALUES ('175','127.0.0.1','0','0','1171639073','groups','manage');
INSERT INTO ezems_stats VALUES ('176','127.0.0.1','0','0','1171639075','groups','remove');
INSERT INTO ezems_stats VALUES ('177','127.0.0.1','0','0','1171639078','groups','remove');
INSERT INTO ezems_stats VALUES ('178','127.0.0.1','0','0','1171639080','groups','manage');
INSERT INTO ezems_stats VALUES ('179','127.0.0.1','0','0','1171639100','groups','edit');
INSERT INTO ezems_stats VALUES ('180','127.0.0.1','0','0','1171639117','groups','manage');
INSERT INTO ezems_stats VALUES ('181','127.0.0.1','0','0','1171639119','groups','add');
INSERT INTO ezems_stats VALUES ('182','127.0.0.1','0','0','1171639123','groups','manage');
INSERT INTO ezems_stats VALUES ('183','127.0.0.1','0','0','1171639126','groups','edit');
INSERT INTO ezems_stats VALUES ('184','127.0.0.1','0','0','1171639235','groups','edit');
INSERT INTO ezems_stats VALUES ('185','127.0.0.1','0','0','1171639269','groups','edit');
INSERT INTO ezems_stats VALUES ('186','127.0.0.1','0','0','1171639271','groups','manage');
INSERT INTO ezems_stats VALUES ('187','127.0.0.1','0','0','1171639381','groups','manage');
INSERT INTO ezems_stats VALUES ('188','127.0.0.1','0','0','1171639434','groups','manage');
INSERT INTO ezems_stats VALUES ('189','127.0.0.1','0','0','1171639450','groups','manage');
INSERT INTO ezems_stats VALUES ('190','127.0.0.1','0','0','1171639456','groups','manage');
INSERT INTO ezems_stats VALUES ('191','127.0.0.1','0','0','1171639494','groups','manage');
INSERT INTO ezems_stats VALUES ('192','127.0.0.1','0','0','1171639516','groups','remove');
INSERT INTO ezems_stats VALUES ('193','127.0.0.1','0','0','1171639521','groups','manage');
INSERT INTO ezems_stats VALUES ('194','127.0.0.1','0','0','1171639524','groups','add');
INSERT INTO ezems_stats VALUES ('195','127.0.0.1','0','0','1171639529','groups','add');
INSERT INTO ezems_stats VALUES ('196','127.0.0.1','0','0','1171639530','groups','manage');
INSERT INTO ezems_stats VALUES ('197','127.0.0.1','0','0','1171639532','groups','remove');
INSERT INTO ezems_stats VALUES ('198','127.0.0.1','0','0','1171639586','groups','remove');
INSERT INTO ezems_stats VALUES ('199','127.0.0.1','0','0','1171639595','groups','remove');
INSERT INTO ezems_stats VALUES ('200','127.0.0.1','0','0','1171639598','groups','remove');
INSERT INTO ezems_stats VALUES ('201','127.0.0.1','0','0','1171639628','groups','remove');
INSERT INTO ezems_stats VALUES ('202','127.0.0.1','0','0','1171639673','groups','remove');
INSERT INTO ezems_stats VALUES ('203','127.0.0.1','0','0','1171639674','groups','manage');
INSERT INTO ezems_stats VALUES ('204','127.0.0.1','0','0','1171639677','groups','add');
INSERT INTO ezems_stats VALUES ('205','127.0.0.1','0','0','1171639680','groups','add');
INSERT INTO ezems_stats VALUES ('206','127.0.0.1','0','0','1171639681','groups','manage');
INSERT INTO ezems_stats VALUES ('207','127.0.0.1','0','0','1171639684','groups','remove');
INSERT INTO ezems_stats VALUES ('208','127.0.0.1','0','0','1171639708','groups','remove');
INSERT INTO ezems_stats VALUES ('209','127.0.0.1','0','0','1171639711','groups','manage');
INSERT INTO ezems_stats VALUES ('210','127.0.0.1','0','0','1171639715','groups','edit');
INSERT INTO ezems_stats VALUES ('211','127.0.0.1','0','0','1171639716','groups','manage');
INSERT INTO ezems_stats VALUES ('212','127.0.0.1','0','0','1171639718','groups','access');
INSERT INTO ezems_stats VALUES ('213','127.0.0.1','0','0','1171639721','groups','manage');
INSERT INTO ezems_stats VALUES ('214','127.0.0.1','0','0','1171639726','groups','add');
INSERT INTO ezems_stats VALUES ('215','127.0.0.1','0','0','1171639727','groups','manage');
INSERT INTO ezems_stats VALUES ('216','127.0.0.1','0','0','1171639730','errors','404');
INSERT INTO ezems_stats VALUES ('217','127.0.0.1','0','0','1171639732','groups','manage');
INSERT INTO ezems_stats VALUES ('218','127.0.0.1','0','0','1171639734','groups','edit');
INSERT INTO ezems_stats VALUES ('219','127.0.0.1','0','0','1171639736','groups','manage');
INSERT INTO ezems_stats VALUES ('220','127.0.0.1','0','0','1171639737','groups','remove');
INSERT INTO ezems_stats VALUES ('221','127.0.0.1','0','0','1171639739','groups','remove');
INSERT INTO ezems_stats VALUES ('222','127.0.0.1','0','0','1171639740','groups','manage');
INSERT INTO ezems_stats VALUES ('223','127.0.0.1','0','0','1171639780','stats','manage');
INSERT INTO ezems_stats VALUES ('224','127.0.0.1','0','0','1171639802','stats','online');
INSERT INTO ezems_stats VALUES ('225','127.0.0.1','0','0','1171639813','stats','navi');
INSERT INTO ezems_stats VALUES ('226','127.0.0.1','0','0','1171639825','stats','online');
INSERT INTO ezems_stats VALUES ('227','127.0.0.1','0','0','1171639872','stats','manage');
INSERT INTO ezems_stats VALUES ('228','127.0.0.1','0','0','1171639982','stats','manage');
INSERT INTO ezems_stats VALUES ('229','127.0.0.1','0','0','1171640009','stats','manage');
INSERT INTO ezems_stats VALUES ('230','127.0.0.1','0','0','1171640028','stats','manage');
INSERT INTO ezems_stats VALUES ('231','127.0.0.1','0','0','1171640106','stats','manage');
INSERT INTO ezems_stats VALUES ('232','127.0.0.1','0','0','1171640109','stats','manage');
INSERT INTO ezems_stats VALUES ('233','127.0.0.1','0','0','1171640123','stats','manage');
INSERT INTO ezems_stats VALUES ('234','127.0.0.1','0','0','1171640126','stats','manage');
INSERT INTO ezems_stats VALUES ('235','127.0.0.1','0','0','1171640211','stats','online');
INSERT INTO ezems_stats VALUES ('236','127.0.0.1','0','0','1171640217','stats','online');
INSERT INTO ezems_stats VALUES ('237','127.0.0.1','0','0','1171640223','stats','online');
INSERT INTO ezems_stats VALUES ('238','127.0.0.1','0','0','1171640225','stats','online');
INSERT INTO ezems_stats VALUES ('239','127.0.0.1','0','0','1171640241','stats','online');
INSERT INTO ezems_stats VALUES ('240','127.0.0.1','0','0','1171640242','stats','online');
INSERT INTO ezems_stats VALUES ('241','127.0.0.1','0','0','1171640248','system','admin');
INSERT INTO ezems_stats VALUES ('242','127.0.0.1','0','0','1171640263','users','add');
INSERT INTO ezems_stats VALUES ('243','127.0.0.1','0','0','1171640465','users','add');
INSERT INTO ezems_stats VALUES ('244','127.0.0.1','0','0','1171640503','users','add');
INSERT INTO ezems_stats VALUES ('245','127.0.0.1','0','0','1171640527','users','add');
INSERT INTO ezems_stats VALUES ('246','127.0.0.1','0','0','1171640549','users','add');
INSERT INTO ezems_stats VALUES ('247','127.0.0.1','0','0','1171640579','groups','add');
INSERT INTO ezems_stats VALUES ('248','127.0.0.1','0','0','1171640592','users','add');
INSERT INTO ezems_stats VALUES ('249','127.0.0.1','0','0','1171640733','groups','access');
INSERT INTO ezems_stats VALUES ('250','127.0.0.1','0','0','1171640740','groups','access');
INSERT INTO ezems_stats VALUES ('251','127.0.0.1','0','0','1171640743','groups','access');
INSERT INTO ezems_stats VALUES ('252','127.0.0.1','0','0','1171641090','users','changelanguage');
INSERT INTO ezems_stats VALUES ('253','127.0.0.1','0','0','1171641098','users','changelanguage');
INSERT INTO ezems_stats VALUES ('254','127.0.0.1','0','0','1171641099','users','usercenter');
INSERT INTO ezems_stats VALUES ('255','127.0.0.1','0','0','1171641104','users','changepassword');
INSERT INTO ezems_stats VALUES ('256','127.0.0.1','0','0','1171641231','groups','access');
INSERT INTO ezems_stats VALUES ('257','127.0.0.1','0','0','1171641239','errors','404');
INSERT INTO ezems_stats VALUES ('258','127.0.0.1','0','0','1171641241','users','edit');
INSERT INTO ezems_stats VALUES ('259','127.0.0.1','0','0','1171641248','users','edit');
INSERT INTO ezems_stats VALUES ('260','127.0.0.1','0','0','1171641456','users','edit');
INSERT INTO ezems_stats VALUES ('261','127.0.0.1','0','0','1171641465','users','edit');
INSERT INTO ezems_stats VALUES ('262','127.0.0.1','0','0','1171641472','users','edit');
INSERT INTO ezems_stats VALUES ('263','127.0.0.1','0','0','1171641474','system','admin');
INSERT INTO ezems_stats VALUES ('264','127.0.0.1','0','0','1171641477','users','manage');
INSERT INTO ezems_stats VALUES ('265','127.0.0.1','0','0','1171641480','users','edit');
INSERT INTO ezems_stats VALUES ('266','127.0.0.1','0','0','1171641482','users','manage');
INSERT INTO ezems_stats VALUES ('267','127.0.0.1','0','0','1171641484','users','add');
INSERT INTO ezems_stats VALUES ('268','127.0.0.1','0','0','1171641500','users','add');
INSERT INTO ezems_stats VALUES ('269','127.0.0.1','0','0','1171641502','users','manage');
INSERT INTO ezems_stats VALUES ('270','127.0.0.1','0','0','1171641504','users','edit');
INSERT INTO ezems_stats VALUES ('271','127.0.0.1','0','0','1171641506','users','edit');
INSERT INTO ezems_stats VALUES ('272','127.0.0.1','0','0','1171641508','users','manage');
INSERT INTO ezems_stats VALUES ('273','127.0.0.1','0','0','1171641520','users','home');
INSERT INTO ezems_stats VALUES ('274','127.0.0.1','0','0','1171641529','users','login');
INSERT INTO ezems_stats VALUES ('275','127.0.0.1','0','0','1171641531','users','logout');
INSERT INTO ezems_stats VALUES ('276','127.0.0.1','0','0','1171641533','system','admin');
INSERT INTO ezems_stats VALUES ('277','127.0.0.1','0','0','1171641538','errors','404');
INSERT INTO ezems_stats VALUES ('278','127.0.0.1','0','0','1171641540','users','home');
INSERT INTO ezems_stats VALUES ('279','127.0.0.1','0','0','1171641543','users','login');
INSERT INTO ezems_stats VALUES ('280','127.0.0.1','0','0','1171641560','users','login');
INSERT INTO ezems_stats VALUES ('281','127.0.0.1','0','0','1171641644','users','login');
INSERT INTO ezems_stats VALUES ('282','127.0.0.1','0','0','1171641663','users','login');
INSERT INTO ezems_stats VALUES ('283','127.0.0.1','0','0','1171641667','users','logout');
INSERT INTO ezems_stats VALUES ('284','127.0.0.1','0','0','1171641670','system','admin');
INSERT INTO ezems_stats VALUES ('285','127.0.0.1','0','0','1171641677','errors','404');
INSERT INTO ezems_stats VALUES ('286','127.0.0.1','0','0','1171641687','users','login');
INSERT INTO ezems_stats VALUES ('287','127.0.0.1','0','0','1171641690','errors','404');
INSERT INTO ezems_stats VALUES ('288','127.0.0.1','0','0','1171641693','system','admin');
INSERT INTO ezems_stats VALUES ('289','127.0.0.1','0','0','1171641753','system','admin');
INSERT INTO ezems_stats VALUES ('290','127.0.0.1','0','0','1171641754','users','logout');
INSERT INTO ezems_stats VALUES ('291','127.0.0.1','0','0','1171641756','system','admin');
INSERT INTO ezems_stats VALUES ('292','127.0.0.1','0','0','1171641764','users','login');
INSERT INTO ezems_stats VALUES ('293','127.0.0.1','0','0','1171641766','users','home');
INSERT INTO ezems_stats VALUES ('294','127.0.0.1','0','0','1171641779','users','manage');
INSERT INTO ezems_stats VALUES ('295','127.0.0.1','0','0','1171641786','users','navlogin');
INSERT INTO ezems_stats VALUES ('296','127.0.0.1','0','0','1171641809','users','navonline');
INSERT INTO ezems_stats VALUES ('297','127.0.0.1','0','0','1171641817','users','remove');
INSERT INTO ezems_stats VALUES ('298','127.0.0.1','0','0','1171641932','users','remove');
INSERT INTO ezems_stats VALUES ('299','127.0.0.1','0','0','1171641944','users','remove');
INSERT INTO ezems_stats VALUES ('300','127.0.0.1','0','0','1171641947','users','remove');
INSERT INTO ezems_stats VALUES ('301','127.0.0.1','0','0','1171641948','users','manage');
INSERT INTO ezems_stats VALUES ('302','127.0.0.1','0','0','1171641951','users','remove');
INSERT INTO ezems_stats VALUES ('303','127.0.0.1','0','0','1171641952','users','remove');
INSERT INTO ezems_stats VALUES ('304','127.0.0.1','0','0','1171641953','users','manage');
INSERT INTO ezems_stats VALUES ('305','127.0.0.1','0','0','1171641965','users','usercenter');
INSERT INTO ezems_stats VALUES ('306','127.0.0.1','0','0','1171641977','errors','404');
INSERT INTO ezems_stats VALUES ('307','127.0.0.1','0','0','1171642671','users','edit');
INSERT INTO ezems_stats VALUES ('308','127.0.0.1','0','0','1171642674','system','admin');
INSERT INTO ezems_stats VALUES ('309','127.0.0.1','0','0','1171642677','system','admin');
INSERT INTO ezems_stats VALUES ('310','127.0.0.1','0','0','1171642684','system','settings');
INSERT INTO ezems_stats VALUES ('311','127.0.0.1','0','0','1171642688','system','admin');
INSERT INTO ezems_stats VALUES ('312','127.0.0.1','0','0','1171642694','stats','manage');
INSERT INTO ezems_stats VALUES ('313','127.0.0.1','0','0','1171642696','users','usercenter');
INSERT INTO ezems_stats VALUES ('314','127.0.0.1','0','0','1171642792','groups','edit');
INSERT INTO ezems_stats VALUES ('315','127.0.0.1','0','0','1171642798','groups','access');
INSERT INTO ezems_stats VALUES ('316','127.0.0.1','0','0','1171642939','groups','access');
INSERT INTO ezems_stats VALUES ('317','127.0.0.1','0','0','1171642948','groups','access');
INSERT INTO ezems_stats VALUES ('318','127.0.0.1','0','0','1171642977','groups','access');
INSERT INTO ezems_stats VALUES ('319','127.0.0.1','0','0','1171643014','groups','access');
INSERT INTO ezems_stats VALUES ('320','127.0.0.1','0','0','1171643053','groups','access');
INSERT INTO ezems_stats VALUES ('321','127.0.0.1','0','0','1171643081','groups','access');
INSERT INTO ezems_stats VALUES ('322','127.0.0.1','0','0','1171643119','groups','access');
INSERT INTO ezems_stats VALUES ('323','127.0.0.1','0','0','1171643243','groups','access');
INSERT INTO ezems_stats VALUES ('324','127.0.0.1','0','0','1171643252','groups','access');
INSERT INTO ezems_stats VALUES ('325','127.0.0.1','0','0','1171643262','groups','access');
INSERT INTO ezems_stats VALUES ('326','127.0.0.1','0','0','1171643295','groups','access');
INSERT INTO ezems_stats VALUES ('327','127.0.0.1','0','0','1171643374','groups','access');
INSERT INTO ezems_stats VALUES ('328','127.0.0.1','0','0','1171643393','groups','access');
INSERT INTO ezems_stats VALUES ('329','127.0.0.1','0','0','1171643404','groups','access');
INSERT INTO ezems_stats VALUES ('330','127.0.0.1','0','0','1171643460','groups','access');
INSERT INTO ezems_stats VALUES ('331','127.0.0.1','0','0','1171643465','groups','access');
INSERT INTO ezems_stats VALUES ('332','127.0.0.1','0','0','1171643466','groups','manage');
INSERT INTO ezems_stats VALUES ('333','127.0.0.1','0','0','1171643469','groups','edit');
INSERT INTO ezems_stats VALUES ('334','127.0.0.1','0','0','1171643471','groups','manage');
INSERT INTO ezems_stats VALUES ('335','127.0.0.1','0','0','1171643473','groups','access');
INSERT INTO ezems_stats VALUES ('336','127.0.0.1','0','0','1171643491','groups','access');
INSERT INTO ezems_stats VALUES ('337','127.0.0.1','0','0','1171643513','groups','access');
INSERT INTO ezems_stats VALUES ('338','127.0.0.1','0','0','1171643566','groups','access');
INSERT INTO ezems_stats VALUES ('339','127.0.0.1','0','0','1171643627','groups','access');
INSERT INTO ezems_stats VALUES ('340','127.0.0.1','0','0','1171643634','groups','access');
INSERT INTO ezems_stats VALUES ('341','127.0.0.1','0','0','1171643639','groups','access');
INSERT INTO ezems_stats VALUES ('342','127.0.0.1','0','0','1171643658','groups','access');
INSERT INTO ezems_stats VALUES ('343','127.0.0.1','0','0','1171643755','groups','access');
INSERT INTO ezems_stats VALUES ('344','127.0.0.1','0','0','1171643760','groups','access');
INSERT INTO ezems_stats VALUES ('345','127.0.0.1','0','0','1171643771','groups','access');
INSERT INTO ezems_stats VALUES ('346','127.0.0.1','0','0','1171643780','groups','access');
INSERT INTO ezems_stats VALUES ('347','127.0.0.1','0','0','1171643803','groups','access');
INSERT INTO ezems_stats VALUES ('348','127.0.0.1','0','0','1171643814','groups','access');
INSERT INTO ezems_stats VALUES ('349','127.0.0.1','0','0','1171643823','groups','access');
INSERT INTO ezems_stats VALUES ('350','127.0.0.1','0','0','1171643828','errors','404');
INSERT INTO ezems_stats VALUES ('351','127.0.0.1','0','0','1171643831','groups','access');
INSERT INTO ezems_stats VALUES ('352','127.0.0.1','0','0','1171643857','system','admin');
INSERT INTO ezems_stats VALUES ('353','127.0.0.1','0','0','1171643861','users','usercenter');
INSERT INTO ezems_stats VALUES ('354','127.0.0.1','0','0','1171643862','users','changetheme');
INSERT INTO ezems_stats VALUES ('355','127.0.0.1','0','0','1171643863','users','usercenter');
INSERT INTO ezems_stats VALUES ('356','127.0.0.1','0','0','1171643865','users','changetemplate');
INSERT INTO ezems_stats VALUES ('357','127.0.0.1','0','0','1171643867','users','usercenter');
INSERT INTO ezems_stats VALUES ('358','127.0.0.1','0','0','1171643869','system','admin');
INSERT INTO ezems_stats VALUES ('359','127.0.0.1','0','0','1171643873','system','settings');
INSERT INTO ezems_stats VALUES ('360','127.0.0.1','0','0','1171643884','users','usercenter');
INSERT INTO ezems_stats VALUES ('361','172.179.144.24','0','0','1171645145','system','admin');
INSERT INTO ezems_stats VALUES ('362','172.179.144.24','0','0','1171645152','users','login');
INSERT INTO ezems_stats VALUES ('363','172.179.144.24','0','0','1171645157','users','login');
INSERT INTO ezems_stats VALUES ('364','172.179.144.24','0','0','1171645160','users','login');
INSERT INTO ezems_stats VALUES ('365','172.179.144.24','0','0','1171645184','system','admin');
INSERT INTO ezems_stats VALUES ('366','172.179.144.24','0','0','1171645193','errors','404');
INSERT INTO ezems_stats VALUES ('367','172.179.144.24','0','0','1171645195','system','admin');
INSERT INTO ezems_stats VALUES ('368','127.0.0.1','0','0','1171773324','system','admin');
INSERT INTO ezems_stats VALUES ('369','127.0.0.1','0','0','1171773838','system','admin');
INSERT INTO ezems_stats VALUES ('370','127.0.0.1','0','0','1171773842','system','admin');
INSERT INTO ezems_stats VALUES ('371','127.0.0.1','0','0','1171773878','system','admin');
INSERT INTO ezems_stats VALUES ('372','127.0.0.1','0','0','1171773927','system','admin');
INSERT INTO ezems_stats VALUES ('373','127.0.0.1','0','0','1171773948','system','admin');
INSERT INTO ezems_stats VALUES ('374','127.0.0.1','0','0','1171773961','system','admin');
INSERT INTO ezems_stats VALUES ('375','127.0.0.1','0','0','1171774094','system','admin');
INSERT INTO ezems_stats VALUES ('376','127.0.0.1','0','0','1171774132','system','admin');
INSERT INTO ezems_stats VALUES ('377','127.0.0.1','0','0','1171774337','errors','404');
INSERT INTO ezems_stats VALUES ('378','127.0.0.1','0','0','1171774338','users','usercenter');
INSERT INTO ezems_stats VALUES ('379','127.0.0.1','0','0','1171774340','system','admin');
INSERT INTO ezems_stats VALUES ('380','127.0.0.1','0','0','1171774344','system','settings');
INSERT INTO ezems_stats VALUES ('381','127.0.0.1','0','0','1171774348','system','admin');
INSERT INTO ezems_stats VALUES ('382','127.0.0.1','0','0','1171774360','stats','manage');
INSERT INTO ezems_stats VALUES ('383','127.0.0.1','0','0','1171774363','users','home');
INSERT INTO ezems_stats VALUES ('384','127.0.0.1','0','0','1171774365','users','usercenter');
INSERT INTO ezems_stats VALUES ('385','127.0.0.1','0','0','1171903672','system','admin');
INSERT INTO ezems_stats VALUES ('386','127.0.0.1','0','0','1171940251','system','admin');
INSERT INTO ezems_stats VALUES ('387','127.0.0.1','0','0','1171940317','system','database');
INSERT INTO ezems_stats VALUES ('388','127.0.0.1','0','0','1171983917','system','admin');
INSERT INTO ezems_stats VALUES ('389','127.0.0.1','0','0','1171983922','system','admin');
INSERT INTO ezems_stats VALUES ('390','127.0.0.1','0','0','1171986065','system','admin');
INSERT INTO ezems_stats VALUES ('391','127.0.0.1','0','0','1171986233','system','admin');
INSERT INTO ezems_stats VALUES ('392','127.0.0.1','0','0','1171986301','system','admin');
INSERT INTO ezems_stats VALUES ('393','127.0.0.1','0','0','1171986304','users','manage');
INSERT INTO ezems_stats VALUES ('394','127.0.0.1','0','0','1171986305','system','admin');
INSERT INTO ezems_stats VALUES ('395','127.0.0.1','0','0','1171986307','groups','manage');
INSERT INTO ezems_stats VALUES ('396','127.0.0.1','0','0','1171986310','groups','access');
INSERT INTO ezems_stats VALUES ('397','127.0.0.1','0','0','1171986410','groups','access');
INSERT INTO ezems_stats VALUES ('398','127.0.0.1','0','0','1171986420','groups','access');
INSERT INTO ezems_stats VALUES ('399','127.0.0.1','0','0','1171986423','system','admin');
INSERT INTO ezems_stats VALUES ('400','127.0.0.1','0','0','1171986427','clanwars','manage');
INSERT INTO ezems_stats VALUES ('401','127.0.0.1','0','0','1171986429','clanwars','add');
INSERT INTO ezems_stats VALUES ('402','127.0.0.1','0','0','1171986432','clanwars','manage');
INSERT INTO ezems_stats VALUES ('403','127.0.0.1','0','0','1171986462','clanwars','manage');
INSERT INTO ezems_stats VALUES ('404','127.0.0.1','0','0','1171986464','system','admin');
INSERT INTO ezems_stats VALUES ('405','127.0.0.1','0','0','1171986467','clanwars','manage');
INSERT INTO ezems_stats VALUES ('406','127.0.0.1','0','0','1171986468','clanwars','add');
INSERT INTO ezems_stats VALUES ('407','127.0.0.1','0','0','1171986470','clanwars','manage');
INSERT INTO ezems_stats VALUES ('408','127.0.0.1','0','0','1171986529','clanwars','add');
INSERT INTO ezems_stats VALUES ('409','127.0.0.1','0','0','1171986530','clanwars','manage');
INSERT INTO ezems_stats VALUES ('410','127.0.0.1','0','0','1171986532','clanwars','add');
INSERT INTO ezems_stats VALUES ('411','127.0.0.1','0','0','1171986916','clanwars','add');
INSERT INTO ezems_stats VALUES ('412','127.0.0.1','0','0','1171986927','clanwars','add');
INSERT INTO ezems_stats VALUES ('413','127.0.0.1','0','0','1171987024','clanwars','add');
INSERT INTO ezems_stats VALUES ('414','127.0.0.1','0','0','1171987051','clanwars','add');
INSERT INTO ezems_stats VALUES ('415','127.0.0.1','0','0','1171987102','clanwars','add');
INSERT INTO ezems_stats VALUES ('416','127.0.0.1','0','0','1171987105','clanwars','add');
INSERT INTO ezems_stats VALUES ('417','127.0.0.1','0','0','1171987115','clanwars','add');
INSERT INTO ezems_stats VALUES ('418','127.0.0.1','0','0','1171987116','clanwars','manage');
INSERT INTO ezems_stats VALUES ('419','127.0.0.1','0','0','1171987118','clanwars','add');
INSERT INTO ezems_stats VALUES ('420','127.0.0.1','0','0','1171987148','clanwars','add');
INSERT INTO ezems_stats VALUES ('421','127.0.0.1','0','0','1171987151','clanwars','manage');
INSERT INTO ezems_stats VALUES ('422','127.0.0.1','0','0','1171987299','clanwars','manage');
INSERT INTO ezems_stats VALUES ('423','127.0.0.1','0','0','1171987309','clanwars','manage');
INSERT INTO ezems_stats VALUES ('424','127.0.0.1','0','0','1171987362','clanwars','manage');
INSERT INTO ezems_stats VALUES ('425','127.0.0.1','0','0','1171987402','clanwars','manage');
INSERT INTO ezems_stats VALUES ('426','127.0.0.1','0','0','1171987492','clanwars','manage');
INSERT INTO ezems_stats VALUES ('427','127.0.0.1','0','0','1171987552','clanwars','manage');
INSERT INTO ezems_stats VALUES ('428','127.0.0.1','0','0','1171987601','clanwars','manage');
INSERT INTO ezems_stats VALUES ('429','127.0.0.1','0','0','1171987632','clanwars','manage');
INSERT INTO ezems_stats VALUES ('430','127.0.0.1','0','0','1171987649','clanwars','manage');
INSERT INTO ezems_stats VALUES ('431','127.0.0.1','0','0','1171987709','clanwars','manage');
INSERT INTO ezems_stats VALUES ('432','127.0.0.1','0','0','1171987729','clanwars','manage');
INSERT INTO ezems_stats VALUES ('433','127.0.0.1','0','0','1171987746','clanwars','manage');
INSERT INTO ezems_stats VALUES ('434','127.0.0.1','0','0','1171987782','clanwars','manage');
INSERT INTO ezems_stats VALUES ('435','127.0.0.1','0','0','1171987799','clanwars','add');
INSERT INTO ezems_stats VALUES ('436','127.0.0.1','0','0','1171987816','clanwars','manage');
INSERT INTO ezems_stats VALUES ('437','127.0.0.1','0','0','1171987889','clanwars','manage');
INSERT INTO ezems_stats VALUES ('438','127.0.0.1','0','0','1171987891','clanwars','manage');
INSERT INTO ezems_stats VALUES ('439','127.0.0.1','0','0','1171987894','clanwars','manage');
INSERT INTO ezems_stats VALUES ('440','127.0.0.1','0','0','1171987895','clanwars','manage');
INSERT INTO ezems_stats VALUES ('441','127.0.0.1','0','0','1171987925','clanwars','add');
INSERT INTO ezems_stats VALUES ('442','127.0.0.1','0','0','1171987926','clanwars','manage');
INSERT INTO ezems_stats VALUES ('443','127.0.0.1','0','0','1171987928','clanwars','manage');
INSERT INTO ezems_stats VALUES ('444','127.0.0.1','0','0','1171987942','clanwars','manage');
INSERT INTO ezems_stats VALUES ('445','127.0.0.1','0','0','1171988014','clanwars','manage');
INSERT INTO ezems_stats VALUES ('446','127.0.0.1','0','0','1171988051','clanwars','manage');
INSERT INTO ezems_stats VALUES ('447','127.0.0.1','0','0','1171988058','clanwars','add');
INSERT INTO ezems_stats VALUES ('448','172.180.238.210','0','0','1171988253','system','admin');
INSERT INTO ezems_stats VALUES ('449','172.180.238.210','0','0','1171988260','users','login');
INSERT INTO ezems_stats VALUES ('450','172.180.238.210','0','0','1171988263','system','admin');
INSERT INTO ezems_stats VALUES ('451','172.180.238.210','0','0','1171988268','clanwars','manage');
INSERT INTO ezems_stats VALUES ('452','172.180.238.210','0','0','1171988320','clanwars','add');
INSERT INTO ezems_stats VALUES ('453','172.180.238.210','0','0','1171988331','clanwars','manage');
INSERT INTO ezems_stats VALUES ('454','172.180.238.210','0','0','1171988342','system','admin');
INSERT INTO ezems_stats VALUES ('455','127.0.0.1','0','0','1171988350','system','admin');
INSERT INTO ezems_stats VALUES ('456','172.180.238.210','0','0','1171988353','clanwars','manage');
INSERT INTO ezems_stats VALUES ('457','127.0.0.1','0','0','1171988359','clanwars','manage');
INSERT INTO ezems_stats VALUES ('458','172.180.238.210','0','0','1171988371','system','admin');
INSERT INTO ezems_stats VALUES ('459','127.0.0.1','0','0','1171988435','clanwars','manage');
INSERT INTO ezems_stats VALUES ('460','127.0.0.1','0','0','1171988536','clanwars','manage');
INSERT INTO ezems_stats VALUES ('461','127.0.0.1','0','0','1171988537','clanwars','manage');
INSERT INTO ezems_stats VALUES ('462','127.0.0.1','0','0','1171988539','clanwars','add');
INSERT INTO ezems_stats VALUES ('463','127.0.0.1','0','0','1171988731','clanwars','add');
INSERT INTO ezems_stats VALUES ('464','127.0.0.1','0','0','1171988737','clanwars','add');
INSERT INTO ezems_stats VALUES ('465','127.0.0.1','0','0','1171988856','clanwars','add');
INSERT INTO ezems_stats VALUES ('466','127.0.0.1','0','0','1171989014','clanwars','add');
INSERT INTO ezems_stats VALUES ('467','127.0.0.1','0','0','1171989045','clanwars','add');
INSERT INTO ezems_stats VALUES ('468','127.0.0.1','0','0','1171989056','clanwars','add');
INSERT INTO ezems_stats VALUES ('469','172.180.238.210','0','0','1171989070','clanwars','manage');
INSERT INTO ezems_stats VALUES ('470','172.180.238.210','0','0','1171989076','clanwars','add');
INSERT INTO ezems_stats VALUES ('471','127.0.0.1','0','0','1171989124','clanwars','add');
INSERT INTO ezems_stats VALUES ('472','172.180.238.210','0','0','1171989130','clanwars','add');
INSERT INTO ezems_stats VALUES ('473','127.0.0.1','0','0','1171989178','clanwars','manage');
INSERT INTO ezems_stats VALUES ('474','127.0.0.1','0','0','1171989181','clanwars','add');
INSERT INTO ezems_stats VALUES ('475','172.180.238.210','0','0','1171989289','clanwars','add');
INSERT INTO ezems_stats VALUES ('476','172.180.238.210','0','0','1171989294','clanwars','add');
INSERT INTO ezems_stats VALUES ('477','172.180.238.210','0','0','1171989297','clanwars','manage');
INSERT INTO ezems_stats VALUES ('478','172.180.238.210','0','0','1171989312','clanwars','add');
INSERT INTO ezems_stats VALUES ('479','172.180.238.210','0','0','1171989366','clanwars','add');
INSERT INTO ezems_stats VALUES ('480','172.180.238.210','0','0','1171989380','clanwars','add');
INSERT INTO ezems_stats VALUES ('481','172.180.238.210','0','0','1171989431','system','admin');
INSERT INTO ezems_stats VALUES ('482','172.180.238.210','0','0','1171989433','clanwars','manage');
INSERT INTO ezems_stats VALUES ('483','172.180.238.210','0','0','1171989440','clanwars','add');
INSERT INTO ezems_stats VALUES ('484','127.0.0.1','0','0','1171989447','clanwars','add');
INSERT INTO ezems_stats VALUES ('485','127.0.0.1','0','0','1171989515','clanwars','add');
INSERT INTO ezems_stats VALUES ('486','172.180.238.210','0','0','1171989522','clanwars','add');
INSERT INTO ezems_stats VALUES ('487','127.0.0.1','0','0','1171989555','clanwars','add');
INSERT INTO ezems_stats VALUES ('488','172.180.238.210','0','0','1171989578','clanwars','add');
INSERT INTO ezems_stats VALUES ('489','172.180.238.210','0','0','1171989590','system','admin');
INSERT INTO ezems_stats VALUES ('490','172.180.238.210','0','0','1171989598','stats','manage');
INSERT INTO ezems_stats VALUES ('491','172.180.238.210','0','0','1171989600','system','admin');
INSERT INTO ezems_stats VALUES ('492','172.180.238.210','0','0','1171989605','system','packages');
INSERT INTO ezems_stats VALUES ('493','172.180.238.210','0','0','1171989613','system','admin');
INSERT INTO ezems_stats VALUES ('494','172.180.238.210','0','0','1171989614','system','admin');
INSERT INTO ezems_stats VALUES ('495','172.180.238.210','0','0','1171989634','clanwars','manage');
INSERT INTO ezems_stats VALUES ('496','172.180.238.210','0','0','1171989637','clanwars','add');
INSERT INTO ezems_stats VALUES ('497','172.180.238.210','0','0','1171989660','system','admin');
INSERT INTO ezems_stats VALUES ('498','172.180.238.210','0','0','1171989663','system','settings');
INSERT INTO ezems_stats VALUES ('499','172.180.238.210','0','0','1171989680','system','admin');
INSERT INTO ezems_stats VALUES ('500','172.180.238.210','0','0','1171989692','bbcode','manage');
INSERT INTO ezems_stats VALUES ('501','172.180.238.210','0','0','1171989694','system','admin');
INSERT INTO ezems_stats VALUES ('502','172.180.238.210','0','0','1171989699','clanwars','manage');
INSERT INTO ezems_stats VALUES ('503','172.180.238.210','0','0','1171989704','clanwars','add');
INSERT INTO ezems_stats VALUES ('504','172.180.238.210','0','0','1171989731','clanwars','add');
INSERT INTO ezems_stats VALUES ('505','172.180.238.210','0','0','1171989889','clanwars','add');
INSERT INTO ezems_stats VALUES ('506','172.180.238.210','0','0','1171989993','clanwars','add');
INSERT INTO ezems_stats VALUES ('507','127.0.0.1','0','0','1171990025','clanwars','add');
INSERT INTO ezems_stats VALUES ('508','172.180.238.210','0','0','1171990031','clanwars','add');
INSERT INTO ezems_stats VALUES ('509','127.0.0.1','0','0','1171990036','clanwars','add');
INSERT INTO ezems_stats VALUES ('510','172.180.238.210','0','0','1171990039','clanwars','add');
INSERT INTO ezems_stats VALUES ('511','127.0.0.1','0','0','1171990071','clanwars','add');
INSERT INTO ezems_stats VALUES ('512','172.180.238.210','0','0','1171990087','clanwars','add');
INSERT INTO ezems_stats VALUES ('513','127.0.0.1','0','0','1171990117','clanwars','add');
INSERT INTO ezems_stats VALUES ('514','172.180.238.210','0','0','1171990120','clanwars','add');
INSERT INTO ezems_stats VALUES ('515','127.0.0.1','0','0','1171990133','clanwars','add');
INSERT INTO ezems_stats VALUES ('516','172.180.238.210','0','0','1171990136','clanwars','add');
INSERT INTO ezems_stats VALUES ('517','127.0.0.1','0','0','1171990171','clanwars','add');
INSERT INTO ezems_stats VALUES ('518','127.0.0.1','0','0','1171990183','clanwars','add');
INSERT INTO ezems_stats VALUES ('519','127.0.0.1','0','0','1171991038','clanwars','add');
INSERT INTO ezems_stats VALUES ('520','127.0.0.1','0','0','1171991113','clanwars','add');
INSERT INTO ezems_stats VALUES ('521','127.0.0.1','0','0','1171991467','clanwars','add');
INSERT INTO ezems_stats VALUES ('522','127.0.0.1','0','0','1171991469','clanwars','manage');
INSERT INTO ezems_stats VALUES ('523','127.0.0.1','0','0','1171991469','clanwars','manage');
INSERT INTO ezems_stats VALUES ('524','127.0.0.1','0','0','1171991470','clanwars','manage');
INSERT INTO ezems_stats VALUES ('525','127.0.0.1','0','0','1171991574','clanwars','manage');
INSERT INTO ezems_stats VALUES ('526','127.0.0.1','0','0','1171991575','clanwars','manage');
INSERT INTO ezems_stats VALUES ('527','127.0.0.1','0','0','1171991575','clanwars','manage');
INSERT INTO ezems_stats VALUES ('528','127.0.0.1','0','0','1171991577','clanwars','add');
INSERT INTO ezems_stats VALUES ('529','172.180.238.210','0','0','1171991645','system','admin');
INSERT INTO ezems_stats VALUES ('530','172.180.238.210','0','0','1171991648','users','logout');
INSERT INTO ezems_stats VALUES ('531','172.180.238.210','0','0','1171991652','system','admin');
INSERT INTO ezems_stats VALUES ('532','172.180.238.210','0','0','1171991655','stats','online');
INSERT INTO ezems_stats VALUES ('533','127.0.0.1','0','0','1171991764','clanwars','manage');
INSERT INTO ezems_stats VALUES ('534','127.0.0.1','0','0','1171991765','clanwars','manage');
INSERT INTO ezems_stats VALUES ('535','127.0.0.1','0','0','1171991766','clanwars','manage');
INSERT INTO ezems_stats VALUES ('536','127.0.0.1','0','0','1171991768','clanwars','add');
INSERT INTO ezems_stats VALUES ('537','127.0.0.1','0','0','1171991851','clanwars','add');
INSERT INTO ezems_stats VALUES ('538','127.0.0.1','0','0','1171991854','clanwars','manage');
INSERT INTO ezems_stats VALUES ('539','127.0.0.1','0','0','1171991854','clanwars','manage');
INSERT INTO ezems_stats VALUES ('540','127.0.0.1','0','0','1171991855','clanwars','manage');
INSERT INTO ezems_stats VALUES ('541','127.0.0.1','0','0','1171991858','clanwars','add');
INSERT INTO ezems_stats VALUES ('542','127.0.0.1','0','0','1171991939','clanwars','add');
INSERT INTO ezems_stats VALUES ('543','127.0.0.1','0','0','1171992170','clanwars','add');
INSERT INTO ezems_stats VALUES ('544','127.0.0.1','0','0','1171992222','clanwars','add');
INSERT INTO ezems_stats VALUES ('545','127.0.0.1','0','0','1171992229','clanwars','add');
INSERT INTO ezems_stats VALUES ('546','127.0.0.1','0','0','1171992240','clanwars','add');
INSERT INTO ezems_stats VALUES ('547','127.0.0.1','0','0','1171992356','clanwars','add');
INSERT INTO ezems_stats VALUES ('548','127.0.0.1','0','0','1171992389','clanwars','add');
INSERT INTO ezems_stats VALUES ('549','127.0.0.1','0','0','1171992434','clanwars','add');
INSERT INTO ezems_stats VALUES ('550','127.0.0.1','0','0','1171992489','clanwars','add');
INSERT INTO ezems_stats VALUES ('551','127.0.0.1','0','0','1171992496','clanwars','add');
INSERT INTO ezems_stats VALUES ('552','127.0.0.1','0','0','1171992515','clanwars','add');
INSERT INTO ezems_stats VALUES ('553','127.0.0.1','0','0','1171992530','clanwars','add');
INSERT INTO ezems_stats VALUES ('554','127.0.0.1','0','0','1171992545','clanwars','add');
INSERT INTO ezems_stats VALUES ('555','127.0.0.1','0','0','1171992549','clanwars','add');
INSERT INTO ezems_stats VALUES ('556','127.0.0.1','0','0','1171992641','clanwars','add');
INSERT INTO ezems_stats VALUES ('557','127.0.0.1','0','0','1171992653','clanwars','add');
INSERT INTO ezems_stats VALUES ('558','127.0.0.1','0','0','1171992671','clanwars','add');
INSERT INTO ezems_stats VALUES ('559','127.0.0.1','0','0','1171992721','clanwars','add');
INSERT INTO ezems_stats VALUES ('560','127.0.0.1','0','0','1171992737','clanwars','add');
INSERT INTO ezems_stats VALUES ('561','127.0.0.1','0','0','1171992784','clanwars','add');
INSERT INTO ezems_stats VALUES ('562','127.0.0.1','0','0','1171992787','clanwars','manage');
INSERT INTO ezems_stats VALUES ('563','127.0.0.1','0','0','1171992788','clanwars','manage');
INSERT INTO ezems_stats VALUES ('564','127.0.0.1','0','0','1171992788','clanwars','manage');
INSERT INTO ezems_stats VALUES ('565','127.0.0.1','0','0','1171992806','clanwars','manage');
INSERT INTO ezems_stats VALUES ('566','127.0.0.1','0','0','1171992807','clanwars','manage');
INSERT INTO ezems_stats VALUES ('567','127.0.0.1','0','0','1171992807','clanwars','manage');
INSERT INTO ezems_stats VALUES ('568','127.0.0.1','0','0','1171992810','clanwars','add');
INSERT INTO ezems_stats VALUES ('569','127.0.0.1','0','0','1171992813','clanwars','add');
INSERT INTO ezems_stats VALUES ('570','127.0.0.1','0','0','1171992905','clanwars','add');
INSERT INTO ezems_stats VALUES ('571','127.0.0.1','0','0','1171992918','clanwars','add');
INSERT INTO ezems_stats VALUES ('572','127.0.0.1','0','0','1171993015','clanwars','add');
INSERT INTO ezems_stats VALUES ('573','127.0.0.1','0','0','1171993019','clanwars','manage');
INSERT INTO ezems_stats VALUES ('574','127.0.0.1','0','0','1171993020','clanwars','manage');
INSERT INTO ezems_stats VALUES ('575','127.0.0.1','0','0','1171993021','clanwars','manage');
INSERT INTO ezems_stats VALUES ('576','127.0.0.1','0','0','1171993022','clanwars','add');
INSERT INTO ezems_stats VALUES ('577','127.0.0.1','0','0','1171993137','clanwars','manage');
INSERT INTO ezems_stats VALUES ('578','127.0.0.1','0','0','1171993138','clanwars','manage');
INSERT INTO ezems_stats VALUES ('579','127.0.0.1','0','0','1171993138','clanwars','manage');
INSERT INTO ezems_stats VALUES ('580','127.0.0.1','0','0','1171993144','system','admin');
INSERT INTO ezems_stats VALUES ('581','127.0.0.1','0','0','1171993148','clanwars','manage');
INSERT INTO ezems_stats VALUES ('582','127.0.0.1','0','0','1171993148','clanwars','manage');
INSERT INTO ezems_stats VALUES ('583','127.0.0.1','0','0','1171993149','clanwars','manage');
INSERT INTO ezems_stats VALUES ('584','127.0.0.1','0','0','1171993152','clanwars','edit');
INSERT INTO ezems_stats VALUES ('585','127.0.0.1','0','0','1171993476','system','admin');
INSERT INTO ezems_stats VALUES ('586','127.0.0.1','0','0','1171993483','system','database');
INSERT INTO ezems_stats VALUES ('587','127.0.0.1','0','0','1171993486','system','database');
INSERT INTO ezems_stats VALUES ('588','127.0.0.1','0','0','1171993488','system','database');
INSERT INTO ezems_stats VALUES ('589','127.0.0.1','0','0','1171993491','system','database');
INSERT INTO ezems_stats VALUES ('590','127.0.0.1','0','0','1171993494','system','database');
INSERT INTO ezems_stats VALUES ('591','127.0.0.1','0','0','1171993510','system','database');
INSERT INTO ezems_stats VALUES ('592','127.0.0.1','0','0','1171993513','system','database');
INSERT INTO ezems_stats VALUES ('593','127.0.0.1','0','0','1171993526','system','database');
INSERT INTO ezems_stats VALUES ('594','127.0.0.1','0','0','1171993528','system','database');
INSERT INTO ezems_stats VALUES ('595','127.0.0.1','0','0','1171993532','system','database');
INSERT INTO ezems_stats VALUES ('596','127.0.0.1','0','0','1171993533','system','database');
INSERT INTO ezems_stats VALUES ('597','127.0.0.1','0','0','1171993536','system','database');
INSERT INTO ezems_stats VALUES ('598','127.0.0.1','0','0','1171993538','system','database');
INSERT INTO ezems_stats VALUES ('599','127.0.0.1','0','0','1171993539','system','admin');
INSERT INTO ezems_stats VALUES ('600','127.0.0.1','0','0','1171993543','system','settings');
INSERT INTO ezems_stats VALUES ('601','127.0.0.1','0','0','1171993548','system','settings');
INSERT INTO ezems_stats VALUES ('602','127.0.0.1','0','0','1171993549','system','admin');
INSERT INTO ezems_stats VALUES ('603','127.0.0.1','0','0','1171993553','system','settings');
INSERT INTO ezems_stats VALUES ('604','127.0.0.1','0','0','1171993555','system','admin');
INSERT INTO ezems_stats VALUES ('605','127.0.0.1','0','0','1171993559','system','database');
INSERT INTO ezems_stats VALUES ('606','127.0.0.1','0','0','1171993562','system','database');
INSERT INTO ezems_stats VALUES ('607','127.0.0.1','0','0','1171993564','system','database');
INSERT INTO ezems_stats VALUES ('608','127.0.0.1','0','0','1171993567','system','database');
INSERT INTO ezems_stats VALUES ('609','127.0.0.1','0','0','1171993568','system','database');
INSERT INTO ezems_stats VALUES ('610','127.0.0.1','0','0','1171993575','system','database');



# ----------------------------------------------------------
#
#
# data for table 'ezems_templates'
#
INSERT INTO ezems_templates VALUES ('1','defaulttables','Default Table Templates','Phoenix','http://www.ec-cp.net','Tabellenbasierte Standarttemplates','1148221618');



# ----------------------------------------------------------
#
#
# data for table 'ezems_themes'
#
INSERT INTO ezems_themes VALUES ('1','water','Water','Phoenix','http://www.ec-cp.net','Standart Theme von Ezems','1148221618');
INSERT INTO ezems_themes VALUES ('2','graphite','Graphite','Phoenix','http://www.ezems.net','Graphite Theme','1148221618');
INSERT INTO ezems_themes VALUES ('3','4future','4Future Design','Phoenix & Phenex','http://www.4-future.net','Designhomepage','0');



# ----------------------------------------------------------
#
#
# data for table 'ezems_users'
#
INSERT INTO ezems_users VALUES ('1','admin','cb1dc18279ac7ff8a78ec2d7aa9efd4a','1','1','1','3','2','1171580919','0','Christian','R�egg','info@ezems.net',NULL);
INSERT INTO ezems_users VALUES ('2','master','ca5a7dc9d04717fd3213b6c86f8ee47c','1','1','1','3','2','1171991648','0','Phillip','Wadecki','info@ezems.net',NULL);
INSERT INTO ezems_users VALUES ('9','COOLover','ac1445af464eb9f1b542f87aa8126bc3','1','1','1','3','2','1171993575','0','Marco','Fester','webmaster@scz-clan.info','1160784784');


